
console.log("🔧 auth.js loaded");

// إعداد Firebase مرة واحدة فقط
if (!firebase.apps.length) {
  const firebaseConfig = {
    apiKey: "AIzaSyDkzGGkyYGVP5tMaqQof1HKTE9bwiysI08",
    authDomain: "packagedeliverytracker.firebaseapp.com",
    projectId: "packagedeliverytracker",
    storageBucket: "packagedeliverytracker.appspot.com",
    messagingSenderId: "372105721161",
    appId: "1:372105721161:web:74bc582fa9389474531698",
    measurementId: "G-3TFD254CXX"
  };
  firebase.initializeApp(firebaseConfig);
}

const auth = firebase.auth();
const db   = firebase.firestore();

// --- تسجيل الدخول ---
const loginForm = document.getElementById("loginForm");
if (loginForm) {
  loginForm.addEventListener("submit", async e => {
    e.preventDefault();
    const email = document.getElementById("loginEmail").value.trim();
    const pass  = document.getElementById("loginPassword").value;

    try {
      const cred = await auth.signInWithEmailAndPassword(email, pass);
      const snap = await db.collection("users").doc(cred.user.uid).get();
      const role = snap.data().role;

      if (role === "admin") location.href = "dashboard.html";
      else if (role === "driver") location.href = "driver.html";
      else location.href = "track.html";

    } catch (err) {
      alert("Login failed: " + err.message);
      console.error(err);
    }
  });
}

// --- التسجيل ---
const roleSelect      = document.getElementById("role");
const addressFields   = document.getElementById("addressFields");

if (roleSelect && addressFields) {
  roleSelect.addEventListener("change", () => {
    if (roleSelect.value === "customer") {
      addressFields.style.display = "block";
      document.getElementById("country").required = true;
      document.getElementById("city").required = true;
      document.getElementById("neighborhood").required = true;
    } else {
      addressFields.style.display = "none";
      document.getElementById("country").required = false;
      document.getElementById("city").required = false;
      document.getElementById("neighborhood").required = false;
    }
  });
}

const registerForm = document.getElementById("registerForm");
if (registerForm) {
  registerForm.addEventListener("submit", async e => {
    e.preventDefault();

    const name     = document.getElementById("fullName").value.trim();
    const email    = document.getElementById("registerEmail").value.trim();
    const pass     = document.getElementById("registerPassword").value;
    const role     = roleSelect.value;

    let country = "", city = "", neighborhood = "";
    if (role === "customer") {
      country      = document.getElementById("country").value.trim();
      city         = document.getElementById("city").value.trim();
      neighborhood = document.getElementById("neighborhood").value.trim();
    }

    try {
      const cred = await auth.createUserWithEmailAndPassword(email, pass);
      await db.collection("users").doc(cred.user.uid).set({
        fullName: name,
        email: email,
        role: role,
        country: country,
        city: city,
        neighborhood: neighborhood,
        createdAt: firebase.firestore.FieldValue.serverTimestamp()
      });

      if (role === "admin") {
        location.href = "dashboard.html";
      } else if (role === "driver") {
        location.href = "driver.html";
      } else {
        location.href = "track.html";
      }

    } catch (err) {
      console.error(err);
      alert("Registration error: " + err.message);
    }
  });
}
// --- تتبع الطرود ---
const trackForm = document.getElementById("trackForm");
if (trackForm) {
  trackForm.addEventListener("submit", async e => {
    e.preventDefault();
    const trackingNumber = document.getElementById("trackingInput").value.trim();
    const resultDiv = document.getElementById("result");
    resultDiv.innerHTML = "Loading...";

    try {
      const snapshot = await db.collection("packages")
        .where("trackingNumber", "==", trackingNumber)
        .get();

      if (snapshot.empty) {
        resultDiv.innerHTML = "<p>No package found with that tracking number.</p>";
        return;
      }

      snapshot.forEach(doc => {
        const data = doc.data();
        resultDiv.innerHTML = `
          <div>
            <h3>Package Info</h3>
            <p><strong>Sender:</strong> ${data.senderName || "N/A"}</p>
            <p><strong>Receiver:</strong> ${data.receiverName || "N/A"}</p>
            <p><strong>Status:</strong> ${data.status || "Pending"}</p>
          </div>
        `;
      });

    } catch (error) {
      console.error("Error fetching package:", error);
      resultDiv.innerHTML = "<p>Error fetching package. Please try again.</p>";
    }
  });
}
